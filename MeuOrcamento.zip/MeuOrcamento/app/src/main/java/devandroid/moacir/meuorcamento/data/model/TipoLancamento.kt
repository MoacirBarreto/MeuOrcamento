package devandroid.moacir.meuorcamento.data.model

/**
 * Enum para representar os tipos de lançamento financeiro.
 * Cada valor (RECEITA, DESPESA) é um objeto distinto.
 */
