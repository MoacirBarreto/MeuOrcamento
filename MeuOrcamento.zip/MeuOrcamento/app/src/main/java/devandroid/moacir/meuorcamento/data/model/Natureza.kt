package devandroid.moacir.meuorcamento.data.model

enum class Natureza {
    RECEITA,
    DESPESA
}

